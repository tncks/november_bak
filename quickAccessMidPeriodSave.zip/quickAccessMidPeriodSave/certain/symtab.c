/****************************************************/
/* File: symtab.c                                   */
/* Symbol table implementation for the TINY compiler*/
/* (allows only one symbol table)                   */
/* Symbol table is implemented as a chained         */
/* hash table                                       */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"

/* SIZE is the size of the hash table */
#define SIZE 211

/* SHIFT is the power of two used as multiplier
   in hash function  */
#define SHIFT 4
int absoluteDebugEnabled = 0;
/* the hash function */
static int hash ( char * key )
{ int temp = 0;
  int i = 0;
  while (key[i] != '\0')
  { temp = ((temp << SHIFT) + key[i]) % SIZE;
    ++i;
  }
  if (absoluteDebugEnabled)
      printf("(hash) return temp: %d; [ original char *key: (%s) ] \n", temp, key);
  return temp;
}

/* the list of line numbers of the source 
 * code in which a variable is referenced
 */
/*typedef struct LineListRec
   { int lineno;
     struct LineListRec * next;
   } * LineList; */

/* The record in the bucket lists for
 * each variable, including name, 
 * assigned memory location, and
 * the list of line numbers in which
 * it appears in the source code
 */
/*typedef struct BucketListRec
   { char * name;
     LineList lines;
     int memloc ;
     struct BucketListRec * next;
   } * BucketList; */

/* the hash table */
static BucketList hashTable[SIZE];

/* Procedure st_insert inserts line numbers and
 * memory locations into the symbol table
 * loc = memory location is inserted only the
 * first time, otherwise ignored
 */

void resetBucketList(){
  int i;
  for (i = 0; i < SIZE; i++) {
    hashTable[i] = NULL;
  }
}

/* found in table, so just add line number */
void st_insert_line(BucketList l, int lineno) {
    LineList t = l->lines;
    while (t->next != NULL) t = t->next;
    t->next = (LineList) malloc(sizeof(struct LineListRec));
    t->next->lineno = lineno;
    t->next->next = NULL;
} /* st_insert_found */

void st_insert_param(char *scope, int lineno, char *param, int location) {
    if(absoluteDebugEnabled) printf("st_insert_param_starting_point_pass %d\n", lineno);
    //if(scope == NULL) printf("[st_insert_param] scope (param)  is pointing NULL\n"); //for debug
    BucketList l = st_lookup(scope, "Global");
    if(absoluteDebugEnabled) 
        printf("BucketList l mem loc: [%p]\n", &l->param);
    if(absoluteDebugEnabled) 
        printf("l->name: [%s]\n", l->name);
    if(absoluteDebugEnabled) 
        printf("l->scope: [%s]\n", l->scope);
    if(absoluteDebugEnabled) 
        printf("l->vector: [%d]\n", l->vector);
    if(absoluteDebugEnabled) 
        printf("l->typeID: [%d]\n", l->typeID);
    if(absoluteDebugEnabled) 
        printf("l->typeData: [%d]\n", l->typeData);
    List t = l->param->list; //segfault now..
    List aux;
    if(absoluteDebugEnabled)
        printf("[DBG] l param number value: %d\n", l->param->number);
    if(absoluteDebugEnabled)
        printf("[DBG] char *param is pointing the %s\n", param==NULL? "NULL":"NOT NULL");
    l->param->number++;
    if(t != NULL){
      while (t->next != NULL) t = t->next;
      aux = (List) malloc(sizeof(struct ListRec));
      aux->name = param;
      aux->location = location;
      aux->next = NULL;
      t->next = aux;
    }
    else{
      l->param->list = (List) malloc(sizeof(struct ListRec));
      l->param->list->name = param;
      l->param->list->location = location;
      l->param->list->next = NULL;
    }

    if(absoluteDebugEnabled)
        printf("st_insert_param_end_point_pass(this should be printed out) %d\n", lineno);
} /* st_insert_param */

/* variable not yet in table */
void st_insert(char * name, bool vector, char * scope, IdentifierKind typeID, TypeKind typeData, int lineno, int loc) {
  int h = hash(name);
  BucketList l =  hashTable[h];
  while (l != NULL)
    l = l->next;
  l = (BucketList) malloc(sizeof(struct BucketListRec));
  l->name = name;
  l->scope = scope;
  l->vector = vector;
  l->typeID = typeID;
  l->typeData = typeData;
  l->param = (ParamList) malloc(sizeof(struct ParamListRec));
  l->param->number = 0;
  l->param->list = NULL;
  l->lines = (LineList) malloc(sizeof(struct LineListRec));
  l->lines->lineno = lineno;
  l->memloc = loc;
  l->lines->next = NULL;
  l->next = hashTable[h]; //Inserir no início
  hashTable[h] = l;
} /* st_insert */

BucketList st_lookup ( char * name, char * scope )
{ if(absoluteDebugEnabled) printf("[myDebug] BucketList st_lookup function-> name: %s, scope: %s\n", name, scope);
  int h = hash(name);
  //printf("[myDebug] hash checkpoint A pass\n");
  BucketList l =  hashTable[h];
  //printf("[myDebug] hasTable checkpoint B pass\n");
  //while ((l != NULL) && !((strcmp(name,l->name) == 0) && ((strcmp(scope,l->scope) == 0)||(strcmp(l->scope,"Global") == 0))))
    //l = l->next;
while (l != NULL) {
    if (l->name != NULL && l->scope != NULL) {
        if ((strcmp(name, l->name) == 0) && (strcmp(scope, l->scope) == 0 || strcmp(l->scope, "Global") == 0)) {
            // Matching condition found, do something
            if(absoluteDebugEnabled) 
                printf("FOUND\n");
            if(absoluteDebugEnabled) 
                printf("now finish st_lookup, last code line reached\n");
            return l;
        }
    }
    l = l->next;
}


  if(absoluteDebugEnabled)
      printf("NOT FOUND\n");
  if(absoluteDebugEnabled)
      printf("now finish st_lookup, last code line reached\n");
  return l;
}



/*void st_insert( char * name, int lineno, int loc )
{ int h = hash(name);
  BucketList l =  hashTable[h];
  while ((l != NULL) && (strcmp(name,l->name) != 0))
    l = l->next;
  if (l == NULL) 
  { l = (BucketList) malloc(sizeof(struct BucketListRec));
    l->name = name;
    l->lines = (LineList) malloc(sizeof(struct LineListRec));
    l->lines->lineno = lineno;
    l->memloc = loc;
    l->lines->next = NULL;
    l->next = hashTable[h];
    hashTable[h] = l; }
  else 
  { LineList t = l->lines;
    while (t->next != NULL) t = t->next;
    t->next = (LineList) malloc(sizeof(struct LineListRec));
    t->next->lineno = lineno;
    t->next->next = NULL;
  }
}*/ /* st_insert */

/* Function st_lookup returns the memory 
 * location of a variable or -1 if not found
 */
/*int st_lookup ( char * name )
{ int h = hash(name);
  BucketList l =  hashTable[h];
  while ((l != NULL) && (strcmp(name,l->name) != 0))
    l = l->next;
  if (l == NULL) return -1;
  else return l->memloc;
}*/

/* Procedure printSymTab prints a formatted 
 * listing of the symbol table contents 
 * to the listing file
 */
void printSymTab(FILE * listing)
{ 
  int i;
  char *str;
  fprintf(listing," Symbol  Name  Location   scope  Line Numbers\n");
  fprintf(listing,"-------------  --------   -----  ------------\n");
  for (i=0; i < SIZE; ++i)
  { if (hashTable[i] != NULL)
    { BucketList l = hashTable[i];
      while (l != NULL) // loop starting point 
      { LineList t = l->lines;
	str = l->name;
	//
        if (strcmp(str, "receive") == 0 || strcmp(str, "saveRF_in_HD") == 0 || strcmp(str, "setMultiprog") == 0 || strcmp(str, "HD_Transfer_MI") == 0 || strcmp(str, "HD_Write") == 0 || strcmp(str, "execProcess") == 0 || strcmp(str, "delay") == 0 || strcmp(str, "getPC_Process") == 0 || strcmp(str, "HD_Read") == 0 || strcmp(str, "recoveryRF") == 0 || strcmp(str, "setQuantum") == 0 || strcmp(str, "returnMain") == 0 || strcmp(str, "send") == 0 || strcmp(str, "setNumProg") == 0 || strcmp(str, "setAddrCS") == 0) { l=l->next; continue; }
        //
		
	fprintf(listing,"%-14s ",l->name);
        int tmp_ = (l->memloc==-1)? 0 : l->memloc;
        fprintf(listing,"%-8d  ",tmp_);
        fprintf(listing,"%-5s  ",l->scope);
        while (t != NULL)
        { int tmp=(t->lineno==-1)? 0 : t->lineno;
          fprintf(listing,"%4d ",tmp);
          t = t->next;
        }
        fprintf(listing,"\n");
        l = l->next;
      } // end of outer loop
    } // end if
  } // end for
} /* printSymTab */
