#include "symtab.h"
#include "analyze.h"

static BucketList pointer;
static char *scope;
static bool main_declared;
static int location;
int absoluteDebugEnabled3 = 0;

int getLocation(){
  return location;
}

/* Procedure traverse is a generic recursive
 * syntax tree traversal routine:
 * it applies preProc in preorder and postProc
 * in postorder to tree pointed to by t
 */
static void traverse( TreeNode * t, void (* preProc) (TreeNode *), void (* postProc) (TreeNode *) )
{ if (t != NULL)
  {
    if(absoluteDebugEnabled3)
        fprintf(listing, "\nTraversing node: %p\n", t);
    preProc(t);
    if(absoluteDebugEnabled3)
        fprintf(listing, "\npreProc pass\n");
    { 
      for (int i=0; i < MAXCHILDREN; i++) {
        if(absoluteDebugEnabled3)
            fprintf(listing, "i: %d..\n", i);
            if (t->child[i] != NULL) {
                if(absoluteDebugEnabled3)
                    fprintf(listing, "Address of ' [%p]=pnode ' has child, and the child[%d] not NULL, traversing: %p (<-child address)\n",t, i, t->child[i]);
                traverse(t->child[i], preProc, postProc);
            } else {
                if(absoluteDebugEnabled3)
                    fprintf(listing, "child[%d] is NULL\n", i);
            } 
      }
    }
    postProc(t);
    if (t->sibling != NULL) {
            if(absoluteDebugEnabled3)
                fprintf(listing, "Sibling found, traversing: %p\n", t->sibling);
            traverse(t->sibling, preProc, postProc);
    } else {
            if(absoluteDebugEnabled3)
                fprintf(listing, "No sibling node\n");
    }
    //traverse(t->sibling,preProc,postProc);
  }
}

/* nullProc is a do-nothing procedure to
 * generate preorder-only or postorder-only
 * traversals from traverse
 */
static void nullProc(TreeNode * t)
{ 
  if(absoluteDebugEnabled3)
      fprintf(listing,"nullProc(), node t address: [%p]\n", t);
  if (t==NULL) return;
  else return;
}

static void declareError(TreeNode * t, char * message)
{ fprintf(listing,"Declare error at line %d: %s\n",t->lineno,message);
  Error = TRUE;
}

static void typeError(TreeNode * t, char * message)
{ fprintf(listing,"Type error at line %d: %s\n",t->lineno,message);
  Error = TRUE;
}

static void mainError( char * message)
{ fprintf(listing,"Error: %s\n",message);
  Error = TRUE;
}

/* Procedure insertNode inserts
 * identifiers stored in t into
 * the symbol table
 */

static void initializeBucketList(){
  resetBucketList();
  main_declared = false;
  location = 0;
}

static void insertionOfProcessorFunctions(){
  //IN OUT
  st_insert("input", false, "Global", Function, Integer, -1, -1);
  st_insert("output", false, "Global", Function, Void, -1, -1);
  st_insert("delay", false, "Global", Function, Void, -1, -1);
  //HD
  st_insert("HD_Transfer_MI", false, "Global", Function, Void, -1, -1);
  st_insert("HD_Write", false, "Global", Function, Void, -1, -1);
  st_insert("HD_Read", false, "Global", Function, Integer, -1, -1);
  st_insert("saveRF_in_HD", false, "Global", Function, Void, -1, -1);
  st_insert("recoveryRF", false, "Global", Function, Void, -1, -1);
  //Context Switch
  st_insert("setMultiprog", false, "Global", Function, Void, -1, -1);
  st_insert("setQuantum", false, "Global", Function, Void, -1, -1);
  st_insert("setAddrCS", false, "Global", Function, Void, -1, -1);
  st_insert("setNumProg", false, "Global", Function, Void, -1, -1);
  st_insert("execProcess", false, "Global", Function, Void, -1, -1);
  st_insert("getPC_Process", false, "Global", Function, Integer, -1, -1);
  st_insert("returnMain", false, "Global", Function, Void, -1, -1);
  //Redes
  st_insert("receive", false, "Global", Function, Integer, -1, -1);
  st_insert("send", false, "Global", Function, Void, -1, -1);
}

static void insertNode( TreeNode * t) //Preencher tabela de símbolos
{
 if(absoluteDebugEnabled3)
     fprintf(listing,"insertNode(), node t address: [%p]\n", t);
 switch (t->nodekind) {
  case StmtK:
    switch (t->kind.stmt) {
      case IfK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),IfK\n");
        break;
      case WhileK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),WhileK\n");
        break;
      case CallK: //Chamada de função.
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),CallK\n");
        t->attr.scope = "Global";
        pointer = st_lookup(t->attr.name, t->attr.scope);
        if(pointer != NULL){ //A função foi declarada
          st_insert_line(pointer, t->lineno);
          t->type = pointer->typeData;
        }
        else declareError(t, "Undeclared function!");
        break;
      case ReturnK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),ReturnK\n");
        break;
      case AssignK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),AssignK\n");
        break;
      default:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),default\n");
        break;
    }
    break;
  case ExpK:
    switch (t->kind.exp) {
      case OpK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),OpK\n");
        break;
      case ConstK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),ConstK\n");
        break;
      case IdK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),IdK\n");
        t->attr.scope = scope;
        pointer = st_lookup(t->attr.name, t->attr.scope);
        if(pointer != NULL){
          st_insert_line(pointer, t->lineno);
          t->type = pointer->typeData;
        }
        else
          declareError(t, "Undeclared variable!");
        break;
      default:
        break;
      }
      break;
  case DeclK:
    switch (t->kind.decl) {
      case FunK: //Global
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),FunK\n");
        if(strcmp(t->attr.name, "main")==0)
          main_declared = true;
        scope = t->attr.name;
        pointer = st_lookup(t->attr.name, t->attr.scope);
        if(pointer==NULL) //A função não foi declarada
          st_insert(t->attr.name, t->attr.vector, t->attr.scope, Function, t->type, t->lineno, location++);
        else //A função foi declarada
          declareError(t, "Function already declared!");
        break;
      case VarK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),VarK\n");
        if(t->attr.scope==NULL) t->attr.scope = scope;
        pointer = st_lookup(t->attr.name, t->attr.scope);
        if(pointer == NULL){ //variável não declarada
          st_insert(t->attr.name, t->attr.vector, t->attr.scope, Variable, t->type, t->lineno, location);
          if(t->attr.vector) location += t->attr.val;
          else location++;
        } else //variável declarada
          declareError(t, "Variable already declared!");
        break;
      case ParamK:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),ParamK\n");
        if(t->attr.scope==NULL) t->attr.scope = scope;
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),checkpoint 1 pass!\n");
        if(absoluteDebugEnabled3)
	    fprintf(listing,"this line should be shown->[t->attr.name: %s]\n",/* t->attr.name==NULL? "NULL" :*/ t->attr.name);
	if(absoluteDebugEnabled3) fprintf(listing,"this line should be shown->[t->attr.scope: %s]\n",/* t->attr.scope==NULL? "NULL" :*/ t->attr.scope);
        pointer = st_lookup(t->attr.name, t->attr.scope);
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),checkpoint 2 pass!\n");
        if(pointer == NULL){ //Não encontrou
          st_insert (t->attr.name, t->attr.vector, t->attr.scope, Variable, t->type, t->lineno, location);
          st_insert_param (t->attr.scope, t->lineno, t->attr.name, location);
          location++;
        }
        else
          declareError(t, "Variable already declared!");
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),checkpoint 3 pass!, now break; is next instruciton\n");
        break;
      default:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),default\n");
        break;
    }
    break;
  case TypeK:
    switch (t->kind.type) {
      case Void:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),Void\n");
        break;
      case Integer:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),Integer\n");
        break;
      default:
        if(absoluteDebugEnabled3)
            fprintf(listing,"insertNode(),default\n");
        break;
    }
    break;
  default:
    break;
  }
}

/* Function buildSymtab constructs the symbol
 * table by preorder traversal of the syntax tree
 */
void buildSymtab(TreeNode * syntaxTree){
  initializeBucketList();
  insertionOfProcessorFunctions();
  if(absoluteDebugEnabled3)
      fprintf(listing,"\ninsertionOfProcessorFunctions()\n");
  traverse(syntaxTree,insertNode,nullProc); // error point  mark
  if(absoluteDebugEnabled3)
      fprintf(listing,"\ntraverse() work done\n");
  if(absoluteDebugEnabled3)
      fprintf(listing,"\nprintSymTab.. work begin entering..\n");
  if (TraceAnalyze){
    if(!main_declared)
      mainError("Main not declared!");
    if(absoluteDebugEnabled3)
        fprintf(listing,"\nSymbol table:\n\n");
    printSymTab(listing);
    if(absoluteDebugEnabled3)
        fprintf(listing,"\nprintSymTab() work done()\n");
  }
}

/* Procedure checkNode performs
 * type checking at a single tree node
 */
static void checkNode(TreeNode * t)
{
  switch (t->nodekind) {
    case StmtK:
      switch (t->kind.stmt) {
        case IfK:
          if(t->child[0]->type != Boolean)
            typeError(t->child[0],"IF test is not Boolean!");
          break;
        case WhileK:
          if(t->child[0]->type != Boolean)
            typeError(t->child[0],"WHILE test is not Boolean!");
          break;
        case CallK:
          break;
        case ReturnK:
          break;
        case AssignK:
          if(t->child[0]->type != t->child[1]->type)
            typeError(t,"ASSIGN: Different types!");
          break;
        default:
          break;
      }
      break;
    case ExpK:
      switch (t->kind.exp) {
        case OpK:
          if ((t->child[0]->type != Integer) || (t->child[1]->type != Integer))
            typeError(t,"OP applied to non-integer!");
          if ( (t->attr.op == LT) || (t->attr.op == LE) || (t->attr.op == GT) || (t->attr.op == GE) || (t->attr.op == EQ) || (t->attr.op == NE) )
            t->type = Boolean;
          else
            t->type = Integer;
          break;
        case ConstK:
          break;
        case IdK:
          break;
        default:
          break;
        }
        break;
    case DeclK:
      switch (t->kind.decl) {
        case FunK:
          break;
        case VarK:
          if(t->type == Void)
            typeError(t,"Variable can't be of type void!");
          break;
        case ParamK:
          break;
        default:
          break;
      }
      break;
    case TypeK:
      switch (t->kind.type) {
        case Void:
          break;
        case Integer:
          break;
        default:
          break;
      }
      break;
    default:
      break;
    }
}


/* Procedure typeCheck performs type checking
 * by a postorder syntax tree traversal
 */
void typeCheck(TreeNode * syntaxTree)
{ traverse(syntaxTree,nullProc,checkNode);
}
